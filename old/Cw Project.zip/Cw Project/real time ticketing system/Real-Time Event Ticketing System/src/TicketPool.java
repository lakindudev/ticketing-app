import java.io.PrintStream;
import java.util.LinkedList;
import java.util.Queue;

//public class TicketPool {
//    private int maximumTicketCapacity;
//    private Queue<Ticket> ticketQueue;
//
//    public TicketPool(int maximumTicketCapacity) {
//        this.maximumTicketCapacity = maximumTicketCapacity;
//        this.ticketQueue = new LinkedList();
//    }
//
//    public synchronized void addTicket(Ticket ticket) {
//        while(this.ticketQueue.size() >= this.maximumTicketCapacity) {
//            try {
//                this.wait();
//            } catch (InterruptedException var3) {
//                InterruptedException e = var3;
//                e.printStackTrace();
//                throw new RuntimeException(e.getMessage());
//            }
//        }
//
//        this.ticketQueue.add(ticket);
//        this.notifyAll();
//        PrintStream var10000 = System.out;
//        String var10001 = Thread.currentThread().getName();
//        var10000.println("Ticket added by - " + var10001 + " - current size is - " + this.ticketQueue.size());
//    }
//
//    public synchronized Ticket buyTicket() {
//        while(this.ticketQueue.isEmpty()) {
//            try {
//                this.wait();
//            } catch (InterruptedException var2) {
//                InterruptedException e = var2;
//                throw new RuntimeException(e.getMessage());
//            }
//        }
//
//        Ticket ticket = (Ticket)this.ticketQueue.poll();
//        this.notifyAll();
//        PrintStream var10000 = System.out;
//        String var10001 = Thread.currentThread().getName();
//        var10000.println("Ticket bought by - " + var10001 + " - current size is - " + this.ticketQueue.size() + " - Ticket is - " + String.valueOf(ticket));
//        return ticket;
//    }
//}

public class TicketPool {
    private int maximumTicketCapacity;
    private Queue<Ticket> ticketQueue;

    public TicketPool(int maximumTicketCapacity) {
        this.maximumTicketCapacity = maximumTicketCapacity;
        this.ticketQueue = new LinkedList<>();
    }

    public synchronized void addTicket(Ticket ticket) {
        while (this.ticketQueue.size() >= this.maximumTicketCapacity) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                if (!Main.running.get()) return; // Exit if stop command issued
                Thread.currentThread().interrupt(); // Restore interrupt status
            }
        }

        this.ticketQueue.add(ticket);
        this.notifyAll();
        System.out.println("Ticket added by - " + Thread.currentThread().getName() + " - current size is - " + this.ticketQueue.size());
    }

    public synchronized Ticket buyTicket() {
        while (this.ticketQueue.isEmpty()) {
            if (!Main.running.get()) return null; // Exit gracefully if stop command issued
            try {
                this.wait();
            } catch (InterruptedException e) {
                if (!Main.running.get()) return null; // Exit if stop command issued
                Thread.currentThread().interrupt(); // Restore interrupt status
            }
        }

        Ticket ticket = this.ticketQueue.poll();
        this.notifyAll();
        System.out.println("Ticket bought by - " + Thread.currentThread().getName() + " - current size is - " + this.ticketQueue.size() + " - Ticket is - " + ticket);
        return ticket;
    }
}

