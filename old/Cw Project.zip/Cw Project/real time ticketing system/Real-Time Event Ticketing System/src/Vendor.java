//
//
//import java.math.BigDecimal;
//
//public class Vendor implements Runnable {
//    private int totalTickets;
//    private int ticketReleaseRate;
//    private TicketPool ticketPool;
//
//    public Vendor(int totalTickets, int ticketReleaseRate, TicketPool ticketPool) {
//        this.totalTickets = totalTickets;
//        this.ticketReleaseRate = ticketReleaseRate;
//        this.ticketPool = ticketPool;
//    }
//
//    public void run() {
//        for(int i = 1; i < this.totalTickets; ++i) {
//            Ticket ticket = new Ticket(i, "Simple Event", new BigDecimal("1000"));
//            this.ticketPool.addTicket(ticket);
//
//            try {
//                Thread.sleep((long)(this.ticketReleaseRate * 1000));
//            } catch (InterruptedException var4) {
//                InterruptedException e = var4;
//                throw new RuntimeException(e);
//            }
//        }
//
//    }
//}
//
//import java.math.BigDecimal;
//
//public class Vendor implements Runnable {
//    private int totalTickets;
//    private int ticketReleaseRate;
//    private TicketPool ticketPool;
//
//    public Vendor(int totalTickets, int ticketReleaseRate, TicketPool ticketPool) {
//        this.totalTickets = totalTickets;
//        this.ticketReleaseRate = ticketReleaseRate;
//        this.ticketPool = ticketPool;
//    }
//
//    public void run() {
//        try {
//            for(int i = 1; i <= this.totalTickets; ++i) {
//                if (Thread.currentThread().isInterrupted()) {
//                    return;
//                }
//
//                Ticket ticket = new Ticket(i, "Simple Event", new BigDecimal("1000"));
//                this.ticketPool.addTicket(ticket);
//
//                try {
//                    Thread.sleep((long)(this.ticketReleaseRate * 1000));
//                } catch (InterruptedException e) {
//                    return;
//                }
//            }
//        } catch (Exception ignored) {
//        }
//    }
//}


import java.math.BigDecimal;

public class Vendor implements Runnable {
    private int totalTickets;
    private int ticketReleaseRate;
    private TicketPool ticketPool;

    public Vendor(int totalTickets, int ticketReleaseRate, TicketPool ticketPool) {
        this.totalTickets = totalTickets;
        this.ticketReleaseRate = ticketReleaseRate;
        this.ticketPool = ticketPool;
    }

    public void run() {
        for (int i = 1; i <= this.totalTickets && Main.running.get(); ++i) {
            Ticket ticket = new Ticket(i, "Simple Event", new BigDecimal("1000"));
            this.ticketPool.addTicket(ticket);

            try {
                Thread.sleep((long) (this.ticketReleaseRate * 1000));
            } catch (InterruptedException e) {
                if (!Main.running.get()) return; // Exit silently if stop command issued
                Thread.currentThread().interrupt(); // Restore interrupt status
            }
        }
    }
}
