//import java.io.PrintStream;
//
//public class Customer implements Runnable {
//    private TicketPool ticketPool;
//    private int customerRetrivelRate;
//    private int quantity;
//
//    public Customer(TicketPool ticketPool, int customerRetrivelRate, int quantity) {
//        this.ticketPool = ticketPool;
//        this.customerRetrivelRate = customerRetrivelRate;
//        this.quantity = quantity;
//    }
//
//    public void run() {
//        for(int i = 0; i < this.quantity; ++i) {
//            Ticket ticket = this.ticketPool.buyTicket();
//            PrintStream var10000 = System.out;
//            String var10001 = String.valueOf(ticket);
//            var10000.println("Ticket is - " + var10001 + " - Customer name is - " + Thread.currentThread().getName());
//
//            try {
//                Thread.sleep((long)(this.customerRetrivelRate * 1000));
//            } catch (InterruptedException var4) {
//                InterruptedException e = var4;
//                throw new RuntimeException(e);
//            }
//        }
//
//    }
//}


//public class Customer implements Runnable {
//    private TicketPool ticketPool;
//    private int customerRetrievalRate;
//    private int quantity;
//
//    public Customer(TicketPool ticketPool, int customerRetrievalRate, int quantity) {
//        this.ticketPool = ticketPool;
//        this.customerRetrievalRate = customerRetrievalRate;
//        this.quantity = quantity;
//    }
//
//    public void run() {
//        try {
//            for(int i = 0; i < this.quantity; ++i) {
//                if (Thread.currentThread().isInterrupted()) {
//                    return;
//                }
//
//                Ticket ticket = this.ticketPool.buyTicket();
//
//                try {
//                    Thread.sleep((long)(this.customerRetrievalRate * 1000));
//                } catch (InterruptedException e) {
//                    return;
//                }
//            }
//        } catch (Exception ignored) {
//        }
//    }
//}


public class Customer implements Runnable {
    private TicketPool ticketPool;
    private int customerRetrievalRate;
    private int quantity;

    public Customer(TicketPool ticketPool, int customerRetrievalRate, int quantity) {
        this.ticketPool = ticketPool;
        this.customerRetrievalRate = customerRetrievalRate;
        this.quantity = quantity;
    }

    public void run() {
        while (Main.running.get()) {
            for (int i = 0; i < this.quantity; i++) {
                Ticket ticket = this.ticketPool.buyTicket();
                if (ticket == null) {
                    return; // Exit silently if no tickets available
                }

                System.out.println("Ticket is - " + ticket + " - Customer name is - " + Thread.currentThread().getName());

                try {
                    Thread.sleep((long) (this.customerRetrievalRate * 1000));
                } catch (InterruptedException e) {
                    if (!Main.running.get()) return; // Exit silently if stop command issued
                    Thread.currentThread().interrupt(); // Restore interrupt status
                }
            }
        }
    }
}


