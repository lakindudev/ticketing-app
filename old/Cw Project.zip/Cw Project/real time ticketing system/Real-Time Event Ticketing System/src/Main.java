import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.atomic.AtomicBoolean;

public class Main {
    // Shared flag to signal all threads to stop
    static final AtomicBoolean running = new AtomicBoolean(true);

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // List to store configurations
        List<TicketConfig> configurations = new ArrayList<>();
        TicketPool ticketPool = null;

        // Arrays to keep track of threads
        Thread[] vendorThreads = null;
        Thread[] customerThreads = null;

        System.out.println("\nCommands: start | stop");
        String command;
        do {
            System.out.print("Enter command: ");
            command = scanner.nextLine().trim().toLowerCase();

            switch (command) {
                case "start":
                    // Reset running flag
                    running.set(true);

                    // Ask about loading existing configuration with input validation
                    TicketConfig ticketConfig = null;
                    while (true) {
                        System.out.println("Would you like to load an existing configuration? (yes/no)");
                        String loadChoice = scanner.nextLine().trim().toLowerCase();

                        if (loadChoice.equals("yes")) {
                            // Try to load configurations from JSON
                            List<TicketConfig> loadedConfigurations = TicketConfig.loadAllFromJson("configurations.json");

                            if (loadedConfigurations != null && !loadedConfigurations.isEmpty()) {
                                // Display available configurations
                                System.out.println("Available Configurations:");
                                for (int i = 0; i < loadedConfigurations.size(); i++) {
                                    TicketConfig config = loadedConfigurations.get(i);
                                    System.out.println("\nConfiguration " + (i + 1) + ":");
                                    System.out.println("Total Tickets: " + config.getTotalTickets());
                                    System.out.println("Ticket Release Rate: " + config.getTicketReleaseRate());
                                    System.out.println("Customer Retrieval Rate: " + config.getCustomerRetrievalRate());
                                    System.out.println("Maximum Ticket Capacity: " + config.getMaxTicketCapacity());
                                }

                                // Ask which configuration to use
                                System.out.print("Enter the configuration number to use (1-" + loadedConfigurations.size() + "): ");
                                int configChoice;
                                while (true) {
                                    try {
                                        configChoice = Integer.parseInt(scanner.nextLine().trim());
                                        if (configChoice > 0 && configChoice <= loadedConfigurations.size()) {
                                            ticketConfig = loadedConfigurations.get(configChoice - 1);
                                            break;
                                        } else {
                                            System.out.print("Invalid configuration number. Please try again: ");
                                        }
                                    } catch (NumberFormatException e) {
                                        System.out.print("Please enter a valid number: ");
                                    }
                                }
                                break;
                            } else {
                                System.out.println("No existing configurations found. Creating a new configuration.");
                                ticketConfig = new TicketConfig();
                                ticketConfig.configureSystemParameters();
                                break;
                            }
                        } else if (loadChoice.equals("no")) {
                            // Create a new configuration
                            ticketConfig = new TicketConfig();
                            ticketConfig.configureSystemParameters();
                            break;
                        } else {
                            System.out.println("Invalid input. Please enter 'yes' or 'no'.");
                        }
                    }

                    // Add the configuration to the list
                    configurations.add(ticketConfig);

                    // Save configurations to JSON
                    TicketConfig.saveAllToJson("configurations.json", configurations);

                    // Initialize TicketPool
                    ticketPool = new TicketPool(ticketConfig.getMaxTicketCapacity());

                    // Start Vendors
                    vendorThreads = new Thread[5];
                    Vendor[] vendors = new Vendor[5];
                    for (int i = 0; i < vendors.length; ++i) {
                        vendors[i] = new Vendor(
                                ticketConfig.getTotalTickets(),
                                ticketConfig.getTicketReleaseRate(),
                                ticketPool
                        );
                        vendorThreads[i] = new Thread(vendors[i], "Vendor-" + i);
                        vendorThreads[i].start();
                    }

                    // Start Customers
                    customerThreads = new Thread[5];
                    Customer[] customers = new Customer[5];
                    for (int i = 0; i < customers.length; ++i) {
                        customers[i] = new Customer(
                                ticketPool,
                                ticketConfig.getCustomerRetrievalRate(),
                                5  // Assume each customer buys 5 tickets
                        );
                        customerThreads[i] = new Thread(customers[i], "Customer-" + i);
                        customerThreads[i].start();
                    }
                    break;

                case "stop":
                    System.out.println("Stopping the program...");

                    // Set the running flag too false to signal threads to stop
                    running.set(false);

                    // Wait for all threads to terminate without printing "stopped" messages
                    if (vendorThreads != null) {
                        for (Thread vendorThread : vendorThreads) {
                            try {
                                if (vendorThread != null) {
                                    vendorThread.interrupt();
                                    vendorThread.join(); // Remove any print statements here
                                }
                            } catch (InterruptedException e) {
                                Thread.currentThread().interrupt(); // Restore interrupt status
                            }
                        }
                    }

                    if (customerThreads != null) {
                        for (Thread customerThread : customerThreads) {
                            try {
                                if (customerThread != null) {
                                    customerThread.interrupt();
                                    customerThread.join(); // Remove any print statements here
                                }
                            } catch (InterruptedException e) {
                                Thread.currentThread().interrupt(); // Restore interrupt status
                            }
                        }
                    }
                    break;

                default:
                    System.out.println("Invalid command. Try again.");
            }
        } while (!command.equals("stop"));

        // Close scanner
        scanner.close();

        // Exit the program
        System.exit(0);
    }
}

