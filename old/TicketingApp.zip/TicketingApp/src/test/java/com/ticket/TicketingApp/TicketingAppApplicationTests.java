package com.ticket.TicketingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
