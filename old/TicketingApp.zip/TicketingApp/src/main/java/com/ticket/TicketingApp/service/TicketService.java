package com.ticket.TicketingApp.service;


import com.ticket.TicketingApp.config.TicketSystemConfig;
import com.ticket.TicketingApp.repo.TicketRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class TicketService {
    private final TicketPool ticketPool;
    private final Vendor vendor;
    private final Customer customer;
    private final TicketRepository ticketRepository;
    private final TicketSystemConfig config;

    public void startSystem() {
        for (int i = 0; i < config.getNumVendors(); i++) {
            vendor.run(config.getTotalTickets() / config.getNumVendors(), config.getTicketReleaseRate());
        }

        for (int i = 0; i < config.getNumCustomers(); i++) {
            customer.run(5, config.getCustomerRetrievalRate());  // Assume each customer buys 5 tickets
        }
        log.info("System started with {} vendors and {} customers", config.getNumVendors(), config.getNumCustomers());
    }

    public void stopSystem() {
        vendor.stop();
        customer.stop();
        log.info("System stopped");
    }

    public int getAvailableTickets() {
        return ticketPool.getAvailableTickets();
    }

    public void clearAllTickets() {
        ticketRepository.deleteAll();
        log.info("All tickets cleared");
    }
}
