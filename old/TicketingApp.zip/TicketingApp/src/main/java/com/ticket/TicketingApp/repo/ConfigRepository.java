package com.ticket.TicketingApp.repo;

public interface ConfigRepository {


}
