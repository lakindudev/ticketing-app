package com.ticket.TicketingApp.controller;


import com.ticket.TicketingApp.service.TicketService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/tickets")
public class TicketController {
    private final TicketService ticketService;

    @Autowired
    public TicketController(TicketService ticketService) {
        this.ticketService = ticketService;
    }

    @PostMapping("/start")
    public String startSystem() {
        ticketService.startSystem();
        return "System started";
    }

    @PostMapping("/stop")
    public String stopSystem() {
        ticketService.stopSystem();
        return "System stopped";
    }

    @GetMapping("/available")
    public int getAvailableTickets() {
        return ticketService.getAvailableTickets();
    }

    @PostMapping("/clear")
    public String clearAllTickets() {
        ticketService.clearAllTickets();
        return "All tickets cleared";
    }
}
