package com.ticket.TicketingApp.repo;


import com.ticket.TicketingApp.model.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    @Query("SELECT t FROM Ticket t ORDER BY t.id ASC")
    Optional<Ticket> findFirstByOrderByIdAsc();
}
