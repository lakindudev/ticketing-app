package com.ticket.TicketingApp.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.concurrent.atomic.AtomicBoolean;

@Service
@RequiredArgsConstructor
@Slf4j
public class Customer {
    private final TicketPool ticketPool;
    private final AtomicBoolean running = new AtomicBoolean(true);

    @Async
    public void run(int quantity, int customerRetrievalRate) {
        try {
            for (int i = 0; i < quantity && running.get(); i++) {
                ticketPool.buyTicket();
                Thread.sleep(customerRetrievalRate * 1000L);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Customer thread interrupted", e);
        }
    }

    public void stop() {
        running.set(false);
    }
}

