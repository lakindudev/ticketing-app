package com.ticket.TicketingApp.service;

import com.ticket.TicketingApp.config.TicketSystemConfig;
import com.ticket.TicketingApp.model.Ticket;
import com.ticket.TicketingApp.repo.TicketRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.Semaphore;

@Component
@Slf4j
public class TicketPool {
    private final TicketRepository ticketRepository;
    private final Semaphore semaphore;

    public TicketPool(TicketRepository ticketRepository, TicketSystemConfig config) {
        this.ticketRepository = ticketRepository;
        this.semaphore = new Semaphore(config.getMaxTicketCapacity());
    }

    public void addTicket(Ticket ticket) throws InterruptedException {
        semaphore.acquire();
        ticketRepository.save(ticket);
        log.info("Ticket added - current size is - {}", getAvailableTickets());
    }

    public Ticket buyTicket() throws InterruptedException {
        Ticket ticket = ticketRepository.findFirstByOrderByIdAsc().orElse(null);
        if (ticket != null) {
            ticketRepository.delete(ticket);
            semaphore.release();
            log.info("Ticket bought - current size is - {} - Ticket is - {}", getAvailableTickets(), ticket);
        }
        return ticket;
    }

    public int getAvailableTickets() {
        return (int) ticketRepository.count();
    }
}


