package com.ticket.TicketingApp.service;


import com.ticket.TicketingApp.model.Ticket;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.concurrent.atomic.AtomicBoolean;

@Service
@RequiredArgsConstructor
@Slf4j
public class Vendor {
    private final TicketPool ticketPool;
    private final AtomicBoolean running = new AtomicBoolean(true);

    @Async
    public void run(int totalTickets, int ticketReleaseRate) {
        try {
            for (int i = 1; i <= totalTickets && running.get(); i++) {
                Ticket ticket = new Ticket(null, i, "Simple Event", new BigDecimal("1000"));
                ticketPool.addTicket(ticket);
                Thread.sleep(ticketReleaseRate * 1000L);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Vendor thread interrupted", e);
        }
    }

    public void stop() {
        running.set(false);
    }
}

